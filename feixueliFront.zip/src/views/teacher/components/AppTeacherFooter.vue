<template>
    <div class="AppTeacherFooter">
        教师空间尾部
    </div>
</template>

<script>
export default {
  name: 'AppTeacherFooter',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
