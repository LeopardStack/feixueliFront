<template>
    <div class="teacher_index">
        教师端端首页
    </div>
</template>

<script>
export default {
  name: 'TeacherIndex',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
