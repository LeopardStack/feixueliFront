<template>
    <div class="courses_teaching">
        培训课程教学
    </div>
</template>

<script>
export default {
  name: 'CoursesTeaching',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
