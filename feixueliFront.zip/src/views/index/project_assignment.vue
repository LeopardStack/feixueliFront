<template>
    <div class="project_assignment">
        培训公告信息
    </div>
</template>

<script>
export default {
  name: 'ProjectAssignment',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
