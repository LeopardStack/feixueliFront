<template>
    <div class="teachers_info">
        培训师资信息
    </div>
</template>

<script>
export default {
  name: 'TeachersInfo',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
