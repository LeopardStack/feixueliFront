<template>
    <div class="app_index_footer">
        门户网站界面尾部
    </div>
</template>

<script>
export default {
  name: 'AppIndexFooter',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
