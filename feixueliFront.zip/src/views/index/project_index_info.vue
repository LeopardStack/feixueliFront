<template>
    <div class="project_index_info">
        培训项目公开信息
    </div>
</template>

<script>
export default {
  name: 'ProjectIndexInfo',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
