<template>
    <div class="app_student_footer">
        学生界面尾部
    </div>
</template>

<script>
export default {
  name: 'AppStudentFooter',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
