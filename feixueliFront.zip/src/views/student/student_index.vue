<template>
    <div class="student_index">
        学生端首页
    </div>
</template>

<script>
export default {
  name: 'StudentIndex',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
