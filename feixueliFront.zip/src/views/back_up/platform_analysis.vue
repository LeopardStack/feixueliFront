<template>
    <div class="platform_analysis">
        统计分析
    </div>
</template>

<script>
export default {
  name: 'ProjectAnalysis',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
