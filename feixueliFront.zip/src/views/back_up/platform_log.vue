<template>
    <div class="platform_log">
        平台日志
    </div>
</template>

<script>
export default {
  name: 'ProjectLog',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
