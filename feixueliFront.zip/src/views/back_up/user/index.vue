<template>
    <div class="User">
        用户管理
    </div>
</template>

<script>
export default {
  name: 'ScnuFrontTest01Index',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
