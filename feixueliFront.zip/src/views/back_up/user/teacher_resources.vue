<template>
    <div class="teacher_resources">
        师资库
    </div>
</template>

<script>
export default {
  name: 'ProjectTeacherResources',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
