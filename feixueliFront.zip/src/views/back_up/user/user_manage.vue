<template>
    <div class="user_manage">
        平台管理人员管理
    </div>
</template>

<script>
export default {
  name: 'ScnuFrontTest01UserManage',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
