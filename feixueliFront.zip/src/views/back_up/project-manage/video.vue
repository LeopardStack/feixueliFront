<template>
    <div class="video">
        点播管理
    </div>
</template>

<script>
export default {
  name: 'ProjectVideo',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
