<template>
    <div class="forum">
        项目讨论区管理
    </div>
</template>

<script>
export default {
  name: 'ProjectForum',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
