<template>
    <div class="display_area">
        项目成果展示区管理
    </div>
</template>

<script>
export default {
  name: 'ProjectDisplayArea',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
