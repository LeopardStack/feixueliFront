<template>
    <div class="file_export">
        项目资料导出
    </div>
</template>

<script>
export default {
  name: 'ProjectFileExport',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
