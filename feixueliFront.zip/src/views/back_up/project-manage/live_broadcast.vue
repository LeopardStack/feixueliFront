<template>
    <div class="live_broadcast">
        直播管理
    </div>
</template>

<script>
export default {
  name: 'ProjectLiveBroadcast',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
