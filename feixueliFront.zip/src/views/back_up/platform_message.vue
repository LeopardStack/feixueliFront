<template>
    <div class="platform_message">
        平台消息管理
    </div>
</template>

<script>
export default {
  name: 'ProjectMessage',

  data () {
    return {

    }
  },

  mounted () {

  },

  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
